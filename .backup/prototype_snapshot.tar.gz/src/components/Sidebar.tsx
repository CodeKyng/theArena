import { useState } from 'react'
import { Link, NavLink, useNavigate } from 'react-router-dom'
import {
  Activity,
  Award,
  BookOpen,
  Building2,
  Calendar,
  ChevronDown,
  Compass,
  Flame,
  Home,
  LogOut,
  PanelLeftClose,
  PanelLeftOpen,
  Shield,
  Sliders,
  Target,
  Trophy,
  UserCheck,
  X,
} from 'lucide-react'
import { useArena } from '../app/arenaContext'
import {
  getGovernanceNavItems,
  PERSONAL_NAV_ITEMS,
  PRIMARY_NAV_ITEMS,
  type NavItem,
} from '../app/navigation'
import Brand from './Brand'

function renderNavIcon(icon: NavItem['icon']) {
  switch (icon) {
    case 'home':
      return <Home size={16} />
    case 'missions':
      return <Target size={16} />
    case 'houses':
      return <Flame size={16} />
    case 'explore':
      return <Compass size={16} />
    case 'academy':
      return <BookOpen size={16} />
    case 'events':
      return <Calendar size={16} />
    case 'leaderboards':
      return <Trophy size={16} />
    case 'activity':
      return <Activity size={16} />
    case 'profile':
      return <UserCheck size={16} />
    case 'stewardship':
      return <Shield size={16} />
    case 'control-room':
      return <Sliders size={16} />
  }
}

export default function Sidebar({
  open,
  collapsed,
  onToggleCollapse,
  onClose,
}: {
  open: boolean
  collapsed: boolean
  onToggleCollapse: () => void
  onClose: () => void
}) {
  const {
    state,
    currentMember,
    xpBalance,
    levelProgress,
    activeOrganisation,
    memberOrganisations,
    switchOrg,
    signOut,
  } = useArena()
  const navigate = useNavigate()
  const [orgMenuOpen, setOrgMenuOpen] = useState(false)

  const governanceItems = getGovernanceNavItems(
    currentMember?.id ?? null,
    state.permissionGrants,
  )

  const pendingReviewsCount = state.submissions.filter(
    (s) => s.status === 'submitted' || s.status === 'under_review',
  ).length

  const activeHouseName = currentMember?.primaryHouseId
    ? state.houses.find((h) => h.id === currentMember.primaryHouseId)?.name ?? 'House'
    : 'No House Selected'

  return (
    <>
      {open && (
        <button
          type="button"
          className="mobile-scrim"
          aria-label="Close navigation menu"
          onClick={onClose}
        />
      )}
      <aside className={`sidebar ${open ? 'sidebar-open' : ''}`} aria-label="Primary Arena navigation">
        <div className="sidebar-top">
          <Brand to="/home" />
          <button
            type="button"
            className="sidebar-collapse-btn"
            onClick={onToggleCollapse}
            aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            {collapsed ? <PanelLeftOpen size={15} /> : <PanelLeftClose size={15} />}
          </button>
          <button
            type="button"
            className="icon-button mobile-close"
            onClick={onClose}
            aria-label="Close menu"
            style={{ color: '#fff' }}
          >
            <X size={18} />
          </button>
        </div>

        {/* Workspace / Organisation Switcher */}
        <div style={{ position: 'relative' }}>
          <button
            type="button"
            className="workspace-switch"
            onClick={() => {
              if (!currentMember) {
                navigate('/login')
                onClose()
                return
              }
              setOrgMenuOpen((prev) => !prev)
            }}
            aria-expanded={orgMenuOpen}
          >
            <span className="workspace-avatar">
              {activeOrganisation ? activeOrganisation.name.slice(0, 1).toUpperCase() : currentMember ? currentMember.avatarInitials : 'V'}
            </span>
            <span className="workspace-copy">
              <b>
                {activeOrganisation
                  ? activeOrganisation.name
                  : currentMember
                    ? `${currentMember.displayName}`
                    : 'Visitor View'}
              </b>
              <small>
                {activeOrganisation
                  ? `Org (${activeOrganisation.verificationStatus.replace('_', ' ')})`
                  : currentMember
                    ? `${currentMember.ascendancyRank} · ${activeHouseName}`
                    : 'Public exploration'}
              </small>
            </span>
            <ChevronDown size={14} className="workspace-switch-chevron" />
          </button>

          {orgMenuOpen && currentMember && !collapsed && (
            <div
              style={{
                background: '#163c73',
                border: '1px solid #3c659d',
                borderRadius: 9,
                padding: 6,
                marginBottom: 12,
                display: 'flex',
                flexDirection: 'column',
                gap: 4,
              }}
            >
              <button
                type="button"
                className={`sidebar-link ${!activeOrganisation ? 'active' : ''}`}
                style={{ width: '100%', border: 0, background: !activeOrganisation ? '#1e5cb5' : 'transparent', textAlign: 'left', cursor: 'pointer' }}
                onClick={() => {
                  switchOrg(null)
                  setOrgMenuOpen(false)
                }}
              >
                <UserCheck size={14} />
                <span className="sidebar-link-label">Personal Spartan Context</span>
              </button>
              {memberOrganisations.map((org) => (
                <button
                  key={org.id}
                  type="button"
                  className={`sidebar-link ${activeOrganisation?.id === org.id ? 'active' : ''}`}
                  style={{ width: '100%', border: 0, background: activeOrganisation?.id === org.id ? '#1e5cb5' : 'transparent', textAlign: 'left', cursor: 'pointer' }}
                  onClick={() => {
                    switchOrg(org.id)
                    setOrgMenuOpen(false)
                  }}
                >
                  <Building2 size={14} />
                  <span className="sidebar-link-label">{org.name}</span>
                </button>
              ))}
              <Link
                to="/organisations"
                className="sidebar-link"
                onClick={() => {
                  setOrgMenuOpen(false)
                  onClose()
                }}
              >
                <Building2 size={14} />
                <span className="sidebar-link-label">Manage Organisations</span>
              </Link>
            </div>
          )}
        </div>

        <div className="side-label">ARENA</div>
        <nav className="side-nav">
          {PRIMARY_NAV_ITEMS.map((item) => (
            <NavLink
              key={item.id}
              to={item.path}
              onClick={onClose}
              className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}
            >
              {renderNavIcon(item.icon)}
              <span className="sidebar-link-label">{item.label}</span>
              {item.id === 'missions' && pendingReviewsCount > 0 && currentMember && (
                <em className="nav-count" title="Submissions awaiting review">
                  {pendingReviewsCount}
                </em>
              )}
            </NavLink>
          ))}
        </nav>

        {currentMember && (
          <>
            <div className="side-label">PERSONAL</div>
            <nav className="side-nav">
              {PERSONAL_NAV_ITEMS.map((item) => (
                <NavLink
                  key={item.id}
                  to={item.path}
                  onClick={onClose}
                  className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}
                >
                  {renderNavIcon(item.icon)}
                  <span className="sidebar-link-label">{item.label}</span>
                </NavLink>
              ))}
              <NavLink
                to="/organisations"
                onClick={onClose}
                className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}
              >
                <Building2 size={16} />
                <span className="sidebar-link-label">Organisations</span>
              </NavLink>
            </nav>
          </>
        )}

        {governanceItems.length > 0 && (
          <>
            <div className="side-label">GOVERNANCE</div>
            <nav className="side-nav">
              {governanceItems.map((item) => (
                <NavLink
                  key={item.id}
                  to={item.path}
                  onClick={onClose}
                  className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}
                >
                  {renderNavIcon(item.icon)}
                  <span className="sidebar-link-label">{item.label}</span>
                </NavLink>
              ))}
            </nav>
          </>
        )}

        <div className="sidebar-bottom">
          {currentMember ? (
            <>
              <div className="xp-card">
                <div className="xp-heading">
                  <span>
                    <Award size={12} /> LEVEL {levelProgress.level} · {currentMember.ascendancyRank.toUpperCase()}
                  </span>
                  <b>{xpBalance.spendableXp} SPEND</b>
                </div>
                <strong>{xpBalance.lifetimeXp.toLocaleString()} Lifetime XP</strong>
                <div className="xp-bar">
                  <i style={{ width: `${levelProgress.progressPercent}%` }} />
                </div>
                <small>
                  <span>{xpBalance.reservedXp} XP reserved</span>
                  <span>
                    {levelProgress.isMaxLevel
                      ? 'Max Level 30'
                      : `${levelProgress.xpRemainingToNext} to L${levelProgress.level + 1}`}
                  </span>
                </small>
              </div>

              <div className="profile-mini">
                <span className="avatar avatar-small">{currentMember.avatarInitials}</span>
                <span className="profile-mini-meta">
                  <b>{currentMember.displayName}</b>
                  <small>@{currentMember.username}</small>
                </span>
                <button
                  type="button"
                  className="sidebar-signout"
                  onClick={() => {
                    signOut()
                    onClose()
                  }}
                  aria-label="Sign out to Visitor view"
                  title="Sign out"
                >
                  <LogOut size={15} />
                </button>
              </div>
            </>
          ) : (
            <div className="guest-join">
              <p>Browsing as a Visitor. Sign in to join missions, complete Academy checks, and build your Proof of Work.</p>
              <Link
                to="/login"
                className="button button-bright"
                style={{ width: '100%' }}
                onClick={onClose}
              >
                Sign in / Join Arena
              </Link>
            </div>
          )}
        </div>
      </aside>
    </>
  )
}
