import { useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { Bell, ChevronRight, Menu, Plus, Search } from 'lucide-react'
import { useArena } from '../app/arenaContext'
import { resolveBreadcrumb } from '../app/navigation'

export default function Topbar({ onOpenMobileMenu }: { onOpenMobileMenu: () => void }) {
  const {
    state,
    currentMember,
    unreadNotificationsCount,
    can,
    setSearchModalOpen,
    openQuickCreate,
    markAllNotificationsRead,
    markNotificationRead,
  } = useArena()

  const { pathname } = useLocation()
  const navigate = useNavigate()
  const [notifOpen, setNotifOpen] = useState(false)

  const breadcrumb = resolveBreadcrumb(pathname, (slug) =>
    state.houses.find((h) => h.slug === slug)?.id,
  )

  const myNotifications = currentMember
    ? state.notifications.filter((n) => n.memberId === currentMember.id).slice(0, 8)
    : []

  return (
    <header className="topbar">
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, minWidth: 0 }}>
        <button
          type="button"
          className="icon-button menu-button"
          onClick={onOpenMobileMenu}
          aria-label="Open navigation menu"
        >
          <Menu size={18} />
        </button>

        <nav className="breadcrumbs" aria-label="Breadcrumb">
          <span>{breadcrumb.group}</span>
          <ChevronRight size={13} />
          <b>{breadcrumb.page}</b>
        </nav>
      </div>

      <div className="topbar-actions">
        <button
          type="button"
          className="global-search"
          onClick={() => setSearchModalOpen(true)}
          aria-label="Open global search"
        >
          <Search size={15} />
          <span>Search Arena...</span>
          <kbd>⌘K</kbd>
        </button>

        {currentMember ? (
          <>
            <div className="arena-popover-wrap">
              <button
                type="button"
                className="icon-button notification-button"
                aria-label={`Notifications (${unreadNotificationsCount} unread)`}
                onClick={() => setNotifOpen((prev) => !prev)}
              >
                <Bell size={17} />
                {unreadNotificationsCount > 0 && <i aria-hidden="true" />}
              </button>

              {notifOpen && (
                <div className="arena-popover" role="region" aria-label="Notifications">
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                    <strong style={{ fontSize: 13 }}>Notifications ({unreadNotificationsCount})</strong>
                    {unreadNotificationsCount > 0 && (
                      <button
                        type="button"
                        className="text-link"
                        style={{ border: 0, background: 'none', cursor: 'pointer', fontSize: 12 }}
                        onClick={markAllNotificationsRead}
                      >
                        Mark all read
                      </button>
                    )}
                  </div>
                  {myNotifications.length === 0 ? (
                    <p style={{ margin: 0, fontSize: 12.5, color: '#647790' }}>No notifications yet.</p>
                  ) : (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                      {myNotifications.map((n) => (
                        <button
                          key={n.id}
                          type="button"
                          onClick={() => {
                            markNotificationRead(n.id)
                            setNotifOpen(false)
                            if (n.linkPath) navigate(n.linkPath)
                          }}
                          style={{
                            textAlign: 'left',
                            border: '1px solid #d7e2f1',
                            background: n.read ? '#fff' : '#eff6ff',
                            borderRadius: 8,
                            padding: '8px 10px',
                            cursor: 'pointer',
                          }}
                        >
                          <div style={{ fontSize: 12.5, fontWeight: 700, color: '#080d16' }}>{n.title}</div>
                          <div style={{ fontSize: 11.5, color: '#52647d', marginTop: 2 }}>{n.body}</div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

            <button
              type="button"
              className="button button-bright button-small"
              onClick={() => openQuickCreate(can('mission.create') ? 'mission' : 'project')}
            >
              <Plus size={15} />
              <span className="button-label-hide-xs">Quick Create</span>
            </button>
          </>
        ) : (
          <Link to="/login" className="button button-bright button-small">
            Sign in
          </Link>
        )}
      </div>
    </header>
  )
}
