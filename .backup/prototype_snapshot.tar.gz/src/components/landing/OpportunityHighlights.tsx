import { ArrowRight, ArrowUpRight, Bookmark } from 'lucide-react'
import { Link, useNavigate } from 'react-router-dom'
import { useArena } from '../../app/arenaContext'

export default function OpportunityHighlights() {
  const { state, currentMember, toggleBookmark } = useArena()
  const navigate = useNavigate()
  const featured = state.missions.filter((m) => m.status === 'active').slice(0, 3)

  return (
    <section className="discover-section section-wrap">
      <div className="section-heading">
        <div>
          <div className="section-kicker">ACTIVE MISSIONS</div>
          <h2>Proof of Work in <em>action.</em></h2>
          <p>Funded missions reserve Spendable XP upfront and settle verified contributions to your Ledger and CP.</p>
        </div>
        <Link className="text-link" to="/missions">Browse all missions <ArrowRight size={16} /></Link>
      </div>

      <div className="arena-grid-3">
        {featured.map((mission) => {
          const house = state.houses.find((h) => h.id === mission.houseId)
          const saved = currentMember
            ? state.savedBookmarks.some(
                (b) => b.memberId === currentMember.id && b.targetType === 'mission' && b.targetId === mission.id,
              )
            : false
          return (
            <article className="listing-card" key={mission.id}>
              <div className="listing-top">
                <span className={`org-mark ${house?.tone ?? 'blue'}`}>{house?.glyph ?? '⌘'}</span>
                <span className="listing-kind kind-featured">
                  House {house?.name ?? mission.houseId}
                </span>
                <button
                  type="button"
                  className={`save-button ${saved ? 'saved' : ''}`}
                  aria-label="Bookmark mission"
                  onClick={() => toggleBookmark('mission', mission.id)}
                >
                  <Bookmark size={14} fill={saved ? 'currentColor' : 'none'} />
                </button>
              </div>

              <span className="listing-org">{mission.category} · {mission.difficulty}</span>
              <h3>{mission.title}</h3>
              <p>{mission.description}</p>

              <div className="tag-row">
                {mission.tags.slice(0, 3).map((tag) => (
                  <span className="tag" key={tag}>{tag}</span>
                ))}
              </div>

              <div className="listing-bottom">
                <span className="listing-reward">
                  +{mission.budget.rewardPerContributorXp} XP · +{mission.budget.cpTierValue} CP
                </span>
                <button
                  type="button"
                  className="arrow-button"
                  aria-label={`Inspect ${mission.title}`}
                  onClick={() => navigate(`/missions/${mission.id}`)}
                >
                  View <ArrowUpRight size={14} />
                </button>
              </div>
            </article>
          )
        })}
      </div>
    </section>
  )
}
