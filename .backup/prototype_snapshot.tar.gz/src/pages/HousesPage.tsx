import { useState } from 'react'
import { Link } from 'react-router-dom'
import { ArrowUpRight, CheckCircle2, Flame, Globe2, Users } from 'lucide-react'
import { useArena } from '../app/arenaContext'
import type { HouseId } from '../domain/types'

export default function HousesPage() {
  const { state, currentMember, updateHouses } = useArena()
  const [primary, setPrimary] = useState<string>(currentMember?.primaryHouseId ?? '')
  const [secondary, setSecondary] = useState<string>(currentMember?.secondaryHouseId ?? '')

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
      <div className="arena-hero-banner">
        <span className="section-kicker">THE SIX CANONICAL HOUSES</span>
        <h2>Find your discipline. Build with your House.</h2>
        <p>
          Every Spartan aligns with one Primary House and an optional Secondary House (0 XP for House selection). House Echoes serves both as a canonical outreach House and as a cross-House capability open to all Spartans under strict anti-farming policy.
        </p>
      </div>

      {currentMember && (
        <section className="dashboard-panel" aria-label="House affiliation selector">
          <div className="panel-title">
            <div>
              <span className="section-kicker">YOUR HOUSE AFFILIATION</span>
              <h2>Primary &amp; Secondary House Selection (0 XP)</h2>
            </div>
            {currentMember.primaryHouseId && (
              <span className="listing-kind kind-success">
                <CheckCircle2 size={13} /> Primary: {state.houses.find((h) => h.id === currentMember.primaryHouseId)?.name}
              </span>
            )}
          </div>
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'flex-end' }}>
            <label className="arena-field" style={{ flex: '1 1 200px' }}>
              Primary House
              <select
                className="arena-select"
                value={primary || currentMember.primaryHouseId || ''}
                onChange={(e) => setPrimary(e.target.value)}
              >
                <option value="">Choose Primary House...</option>
                {state.houses.map((h) => (
                  <option key={h.id} value={h.id}>
                    {h.glyph} House {h.name}
                  </option>
                ))}
              </select>
            </label>
            <label className="arena-field" style={{ flex: '1 1 200px' }}>
              Secondary House (optional)
              <select
                className="arena-select"
                value={secondary || currentMember.secondaryHouseId || ''}
                onChange={(e) => setSecondary(e.target.value)}
              >
                <option value="">None</option>
                {state.houses
                  .filter((h) => h.id !== (primary || currentMember.primaryHouseId))
                  .map((h) => (
                    <option key={h.id} value={h.id}>
                      {h.glyph} House {h.name}
                    </option>
                  ))}
              </select>
            </label>
            <button
              type="button"
              className="button button-bright"
              onClick={() => {
                const p = (primary || currentMember.primaryHouseId || null) as HouseId | null
                const s = (secondary || currentMember.secondaryHouseId || null) as HouseId | null
                updateHouses(p, s === p ? null : s)
              }}
            >
              Update Houses (0 XP)
            </button>
          </div>
        </section>
      )}

      <div className="arena-grid-3">
        {state.houses.map((house) => {
          const activeMissions = state.missions.filter((m) => m.houseId === house.id && m.status === 'active').length
          const membersCount = state.members.filter(
            (m) => m.primaryHouseId === house.id || m.secondaryHouseId === house.id,
          ).length
          const isPrimary = currentMember?.primaryHouseId === house.id
          const isSecondary = currentMember?.secondaryHouseId === house.id

          return (
            <article className="listing-card" key={house.id}>
              <div className="listing-top">
                <span className={`org-mark ${house.tone}`}>{house.glyph}</span>
                {house.supportsCrossHouseOutreach ? (
                  <span className="listing-kind kind-featured">
                    <Globe2 size={12} /> Cross-House Capability
                  </span>
                ) : (
                  <span className="listing-kind">
                    <Flame size={12} /> Canonical House
                  </span>
                )}
                {isPrimary && <span className="listing-kind kind-success">Primary</span>}
                {isSecondary && <span className="listing-kind kind-amber">Secondary</span>}
              </div>

              <h3>House {house.name}</h3>
              <p>{house.description}</p>

              <div className="tag-row">
                {house.focusAreas.slice(0, 4).map((area) => (
                  <span className="tag" key={area}>{area}</span>
                ))}
              </div>

              <div className="listing-bottom">
                <span className="listing-reward" style={{ display: 'inline-flex', alignItems: 'center', gap: 10 }}>
                  <span><Users size={13} style={{ verticalAlign: 'middle' }} /> {membersCount}</span>
                  <span>{activeMissions} active missions</span>
                </span>
                <Link className="arrow-button" to={`/houses/${house.slug}`}>
                  Enter <ArrowUpRight size={14} />
                </Link>
              </div>
            </article>
          )
        })}
      </div>
    </div>
  )
}
