import { useState } from 'react'
import { Link } from 'react-router-dom'
import { CheckCircle2, Menu, X } from 'lucide-react'
import { useArena } from '../../app/arenaContext'
import { LANDING_LINKS } from '../../app/navigation'
import Brand from '../../components/Brand'
import DemoPersonaBar from '../../components/DemoPersonaBar'
import CommunitySection from '../../components/landing/CommunitySection'
import HeroSection from '../../components/landing/HeroSection'
import LandingFooter from '../../components/landing/LandingFooter'
import Newsletter from '../../components/landing/Newsletter'
import OpportunityHighlights from '../../components/landing/OpportunityHighlights'

export default function LandingPage() {
  const { currentMember, flash, toast } = useArena()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <div className="landing-app">
      <header className="topbar-landing">
        <Brand />
        <nav className="landing-nav" aria-label="Landing navigation">
          {LANDING_LINKS.map((item) => (
            <Link key={item.to} to={item.to}>{item.label}</Link>
          ))}
        </nav>
        <div className="topbar-actions">
          {currentMember ? (
            <Link className="button button-bright button-small" to="/home">
              Open Workspace
            </Link>
          ) : (
            <>
              <Link className="login-link" to="/login">Sign in</Link>
              <Link className="button button-bright button-small" to="/register">Join Arena</Link>
            </>
          )}
          <button
            type="button"
            className="icon-button landing-mobile-toggle"
            aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
            onClick={() => setMobileMenuOpen((v) => !v)}
          >
            {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </header>

      {mobileMenuOpen && (
        <nav className="landing-mobile-drawer" aria-label="Mobile landing navigation">
          {LANDING_LINKS.map((item) => (
            <Link key={item.to} to={item.to} onClick={() => setMobileMenuOpen(false)}>
              {item.label}
            </Link>
          ))}
          {!currentMember && (
            <Link to="/login" onClick={() => setMobileMenuOpen(false)}>
              Sign in / Switch Demo Persona
            </Link>
          )}
        </nav>
      )}

      <DemoPersonaBar />

      <main className="landing-main">
        <HeroSection />
        <OpportunityHighlights />
        <CommunitySection />
        <Newsletter flash={flash} />
      </main>

      <LandingFooter />

      {toast && (
        <div className="toast" role="status" aria-live="polite">
          <CheckCircle2 size={16} />
          <span>{toast}</span>
        </div>
      )}
    </div>
  )
}
