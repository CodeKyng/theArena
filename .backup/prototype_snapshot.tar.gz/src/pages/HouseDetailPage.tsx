import { useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { AlertTriangle, ArrowLeft, BookOpen, Shield, Target, Users } from 'lucide-react'
import { useArena } from '../app/arenaContext'
import PermissionGate from '../components/PermissionGate'

type HouseTab = 'overview' | 'activity' | 'missions' | 'academy' | 'members' | 'about' | 'management'

export default function HouseDetailPage() {
  const { slug } = useParams<{ slug: string }>()
  const { state, currentMember, can, updateHouses, toggleMissionPause } = useArena()
  const house = state.houses.find((h) => h.slug === slug)
  const [tab, setTab] = useState<HouseTab>('overview')

  if (!house) {
    return (
      <div className="empty-state">
        <h3>House not found</h3>
        <p>Select one of the six canonical Arena Houses.</p>
        <Link className="button button-bright" to="/houses">All Houses</Link>
      </div>
    )
  }

  const canManageHouse = can('house.manage', house.id)
  const houseMissions = state.missions.filter(
    (m) => m.houseId === house.id || (house.id === 'echoes' && m.crossHouseEligible),
  )
  const houseMembers = state.members.filter(
    (m) => m.primaryHouseId === house.id || m.secondaryHouseId === house.id,
  )
  const houseAcademy = state.academyPaths.filter(
    (p) => p.houseId === house.id || p.modules.some((mod) => mod.houseId === house.id),
  )
  const houseContributions = state.contributionRecords.filter((cr) => cr.houseId === house.id)
  const houseSubmissions = state.submissions.filter((sub) =>
    houseMissions.some((m) => m.id === sub.missionId),
  )

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div>
        <Link className="text-link" to="/houses">
          <ArrowLeft size={14} /> All 6 Houses
        </Link>
      </div>

      <div className="arena-hero-banner">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 14, flexWrap: 'wrap' }}>
          <div>
            <span className="section-kicker">
              {house.supportsCrossHouseOutreach ? 'CANONICAL HOUSE + CROSS-HOUSE CAPABILITY' : 'CANONICAL ARENA HOUSE'}
            </span>
            <h2>{house.glyph} House {house.name}</h2>
            <p>{house.tagline} {house.description}</p>
          </div>
          {currentMember && (
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              <button
                type="button"
                className="button button-quiet button-small"
                onClick={() => updateHouses(house.id, currentMember.secondaryHouseId === house.id ? null : currentMember.secondaryHouseId)}
                disabled={currentMember.primaryHouseId === house.id}
              >
                {currentMember.primaryHouseId === house.id ? 'Primary House' : 'Set as Primary (0 XP)'}
              </button>
              <button
                type="button"
                className="button button-quiet button-small"
                onClick={() =>
                  updateHouses(
                    currentMember.primaryHouseId ?? house.id,
                    currentMember.primaryHouseId === house.id ? null : house.id,
                  )
                }
              >
                {currentMember.secondaryHouseId === house.id ? 'Secondary House' : 'Set as Secondary'}
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="arena-tabs" role="tablist">
        {(
          [
            ['overview', 'Overview'],
            ['activity', 'Activity'],
            ['missions', `Missions (${houseMissions.length})`],
            ['academy', `Academy (${houseAcademy.length})`],
            ['members', `Members (${houseMembers.length})`],
            ['about', 'About & Standards'],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            role="tab"
            aria-selected={tab === id}
            className={`arena-tab ${tab === id ? 'active' : ''}`}
            onClick={() => setTab(id)}
          >
            {label}
          </button>
        ))}

        {canManageHouse && (
          <button
            type="button"
            role="tab"
            aria-selected={tab === 'management'}
            className={`arena-tab ${tab === 'management' ? 'active' : ''}`}
            onClick={() => setTab('management')}
          >
            <Shield size={14} /> House Management (Scoped)
          </button>
        )}
      </div>

      {tab === 'overview' && (
        <div className="dashboard-columns">
          <div className="dashboard-panel">
            <div className="panel-title">
              <h2>Focus Areas &amp; Stewardship Standard</h2>
            </div>
            <div className="tag-row" style={{ marginBottom: 14 }}>
              {house.focusAreas.map((fa) => (
                <span className="tag" key={fa}>{fa}</span>
              ))}
            </div>
            <p style={{ margin: '0 0 12px', fontSize: 14 }}>{house.aboutDetails}</p>
            <div className="arena-notice arena-notice-info">
              <span><b>Reviewer standard:</b> {house.stewardsNote}</span>
            </div>
          </div>

          <div className="dashboard-panel">
            <div className="panel-title">
              <h2>Active House Highlights</h2>
              <Link className="text-link" to="/leaderboards">House Leaderboard</Link>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <div className="stat-card">
                <div className="stat-top">Active Missions <span><Target size={15} /></span></div>
                <strong>{houseMissions.filter((m) => m.status === 'active').length}</strong>
                <small><i /> Verified Proof-of-Work deliverables</small>
              </div>
              <div className="stat-card">
                <div className="stat-top">Verified Contributions <span><Users size={15} /></span></div>
                <strong>{houseContributions.length}</strong>
                <small><i /> Permanent House records</small>
              </div>
            </div>
          </div>
        </div>
      )}

      {tab === 'activity' && (
        <div className="dashboard-panel">
          <div className="panel-title"><h2>House Contribution Feed</h2></div>
          {houseContributions.length === 0 ? (
            <p style={{ color: '#52647d', margin: 0 }}>No verified contributions logged in this House yet.</p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {houseContributions.map((cr) => {
                const member = state.members.find((m) => m.id === cr.memberId)
                return (
                  <div key={cr.id} style={{ padding: 12, border: '1px solid #e3ebf5', borderRadius: 8 }}>
                    <div style={{ fontSize: 13.5 }}>
                      <b>{member?.displayName}</b> · {cr.title}
                    </div>
                    <div style={{ fontSize: 12.5, color: '#52647d', marginTop: 3 }}>{cr.deliverableSummary}</div>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      )}

      {tab === 'missions' && (
        <div className="arena-grid-3">
          {houseMissions.map((m) => (
            <article className="listing-card" key={m.id}>
              <div className="listing-top">
                <span className="listing-kind">{m.status}</span>
                {m.crossHouseEligible && <span className="listing-kind kind-featured">Cross-House</span>}
              </div>
              <h3>{m.title}</h3>
              <p>{m.description}</p>
              <div className="listing-bottom">
                <span className="listing-reward">+{m.budget.rewardPerContributorXp} XP · +{m.budget.cpTierValue} CP</span>
                <Link className="arrow-button" to={`/missions/${m.id}`}>Open</Link>
              </div>
            </article>
          ))}
        </div>
      )}

      {tab === 'academy' && (
        <div className="arena-grid-2">
          {houseAcademy.length === 0 ? (
            <div className="dashboard-panel">
              <p style={{ margin: 0, color: '#52647d' }}>
                House-specific modules are complemented by Web3 Foundations &amp; Safety paths in the{' '}
                <Link className="text-link" to="/academy">Arena Academy</Link>.
              </p>
            </div>
          ) : (
            houseAcademy.map((p) => (
              <div className="dashboard-panel" key={p.id}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                  <BookOpen size={17} color="#1e5cb5" />
                  <span className="tag">{p.track}</span>
                </div>
                <h3 style={{ margin: '0 0 6px' }}>{p.title}</h3>
                <p style={{ margin: '0 0 12px', fontSize: 13.5, color: '#52647d' }}>{p.subtitle}</p>
                <Link className="button button-bright button-small" to="/academy">Open Path in Academy</Link>
              </div>
            ))
          )}
        </div>
      )}

      {tab === 'members' && (
        <div className="arena-grid-3">
          {houseMembers.map((m) => (
            <div className="dashboard-panel" key={m.id} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <span className="avatar avatar-small" style={{ width: 42, height: 42, fontSize: 13 }}>{m.avatarInitials}</span>
              <div>
                <div style={{ fontWeight: 700 }}>{m.displayName}</div>
                <div style={{ fontSize: 12, color: '#52647d' }}>
                  {m.ascendancyRank} · {m.primaryHouseId === house.id ? 'Primary' : 'Secondary'}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === 'about' && (
        <div className="dashboard-panel">
          <h2>About House {house.name}</h2>
          <p>{house.aboutDetails}</p>
          {house.supportsCrossHouseOutreach && (
            <div className="arena-notice arena-notice-warn">
              <AlertTriangle size={16} />
              <span>
                <b>Anti-Engagement-Farming Policy:</b> House Echoes strictly prohibits buying likes, reposts, follows, or raw impression counts. All outreach missions verify substance and alignment.
              </span>
            </div>
          )}
        </div>
      )}

      {tab === 'management' && (
        <PermissionGate requiredAny={['house.manage']} houseId={house.id} title={`House ${house.name} Management`}>
          <div className="dashboard-panel">
            <div className="panel-title">
              <div>
                <span className="section-kicker">HOUSE-SCOPED STRATEGOS WORKSPACE</span>
                <h2>Manage House {house.name}</h2>
              </div>
            </div>
            <p style={{ fontSize: 13, color: '#52647d', marginTop: 0 }}>
              Permission check verified: you hold scoped <code>house.manage</code> authority strictly for <b>House {house.name}</b>. You cannot manage other Houses unless explicitly granted scope.
            </p>
            <div className="arena-table-wrap">
              <table className="arena-table">
                <thead>
                  <tr>
                    <th>Mission</th>
                    <th>Status</th>
                    <th>Escrow Remaining</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {houseMissions.filter((m) => m.houseId === house.id).map((m) => (
                    <tr key={m.id}>
                      <td><Link className="text-link" to={`/missions/${m.id}`}>{m.title}</Link></td>
                      <td><span className="listing-kind">{m.status}</span></td>
                      <td>{m.budget.remainingReservedXp} XP</td>
                      <td>
                        <div style={{ display: 'flex', gap: 6 }}>
                          {(m.status === 'active' || m.status === 'paused') && (
                            <button
                              type="button"
                              className="button button-quiet button-small"
                              onClick={() => toggleMissionPause(m.id)}
                            >
                              {m.status === 'active' ? 'Pause' : 'Resume'}
                            </button>
                          )}
                          <Link className="button button-quiet button-small" to={`/missions/${m.id}`}>Review ({houseSubmissions.filter((s) => s.missionId === m.id && s.status === 'submitted').length})</Link>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </PermissionGate>
      )}
    </div>
  )
}
