import { useState, type FormEvent } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { ArrowRight, Info, ShieldCheck, UserPlus } from 'lucide-react'
import { useArena } from '../../app/arenaContext'
import Brand from '../../components/Brand'
import { DEMO_PERSONAS } from '../../domain/constants'

export default function AuthPage({ mode }: { mode: 'login' | 'register' }) {
  const { signInByEmail, registerAccount, switchPersona } = useArena()
  const navigate = useNavigate()

  const [displayName, setDisplayName] = useState('')
  const [username, setUsername] = useState('')
  const [email, setEmail] = useState('')
  const [headline, setHeadline] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [recoverySent, setRecoverySent] = useState(false)

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault()
    setError(null)
    if (mode === 'login') {
      const res = signInByEmail(email)
      if (!res.ok) {
        setError(res.error)
        return
      }
      navigate('/home')
    } else {
      const res = registerAccount({ displayName, username, email, headline })
      if (!res.ok) {
        setError(res.error)
        return
      }
      navigate('/home')
    }
  }

  return (
    <div className="auth-layout">
      <div className="auth-art">
        <Brand />
        <div className="auth-art-copy">
          <div className="section-kicker">UNIFIED ARENA ACCOUNT</div>
          <h1>One identity.<br /><em>Every path.</em></h1>
          <p>
            Every member enters The Arena as a unified Spartan—free to learn, join missions, align with Houses, and optionally create or represent an organisation later without splitting accounts.
          </p>
        </div>
        <div className="auth-art-foot">
          NO ROLE SPLIT ON SIGNUP · CLIENT SIMULATION ONLY (NO PASSWORDS STORED)
        </div>
      </div>

      <div className="auth-main">
        <Link className="back-home" to="/">← Back to landing</Link>

        <div className="auth-form-wrap">
          <div className="section-kicker">{mode === 'login' ? 'SIMULATED SIGN IN' : 'UNIFIED REGISTRATION'}</div>
          <h2>{mode === 'login' ? 'Enter The Arena' : 'Join as a Spartan'}</h2>
          <p>
            {mode === 'login'
              ? 'Sign in with a seeded @arena.demo email or pick one of the 6 demo personas below.'
              : 'Create a unified Spartan account. You will start in the Newbie stage with guided orientation (+20 XP) and House selection.'}
          </p>

          {error && (
            <div className="arena-notice arena-notice-danger" style={{ marginBottom: 14 }}>
              {error}
            </div>
          )}

          {recoverySent && (
            <div className="arena-notice arena-notice-info" style={{ marginBottom: 14 }}>
              <Info size={16} />
              <span>
                Simulated recovery: in this frontend-only prototype no email server exists and no passwords are stored. Use any demo persona below or sign in with <code>jordan.davis@arena.demo</code>.
              </span>
            </div>
          )}

          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 13 }}>
            {mode === 'register' && (
              <>
                <label className="arena-field">
                  Display Name
                  <input
                    required
                    className="arena-input"
                    placeholder="e.g. Samira Patel"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                  />
                </label>
                <label className="arena-field">
                  Arena Handle
                  <input
                    required
                    className="arena-input"
                    placeholder="e.g. samira.patel"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                  />
                </label>
                <label className="arena-field">
                  Short Headline (optional)
                  <input
                    className="arena-input"
                    placeholder="e.g. Protocol researcher & designer"
                    value={headline}
                    onChange={(e) => setHeadline(e.target.value)}
                  />
                </label>
              </>
            )}

            <label className="arena-field">
              Email Address
              <input
                required
                type="email"
                className="arena-input"
                placeholder={mode === 'login' ? 'jordan.davis@arena.demo' : 'you@example.com'}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </label>

            {mode === 'login' && (
              <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                <button
                  type="button"
                  className="text-link"
                  style={{ border: 0, background: 'none', cursor: 'pointer', fontSize: 12.5 }}
                  onClick={() => setRecoverySent(true)}
                >
                  Simulated password help?
                </button>
              </div>
            )}

            <button type="submit" className="button button-bright" style={{ width: '100%' }}>
              {mode === 'login' ? (
                <>Sign in to Workspace <ArrowRight size={15} /></>
              ) : (
                <>Create Unified Spartan Account <UserPlus size={15} /></>
              )}
            </button>
          </form>

          <div style={{ textAlign: 'center', marginTop: 14, fontSize: 13, color: '#52647d' }}>
            {mode === 'login' ? (
              <>
                New to The Arena? <Link className="text-link" to="/register">Create a unified account</Link>
              </>
            ) : (
              <>
                Already registered? <Link className="text-link" to="/login">Sign in</Link>
              </>
            )}
          </div>

          <div style={{ marginTop: 22 }}>
            <div className="section-kicker" style={{ marginBottom: 4 }}>INSTANT DEMO PERSONAS (CLIENT SIMULATION)</div>
            <div className="demo-role-grid">
              {DEMO_PERSONAS.filter((p) => p.memberId !== null).map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => {
                    switchPersona(p.memberId)
                    navigate('/home')
                  }}
                >
                  <ShieldCheck size={16} color="#1e5cb5" style={{ marginTop: 2 }} />
                  <span style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                    <b style={{ fontSize: 12.5, color: '#080d16' }}>{p.label}</b>
                    <small style={{ fontSize: 11, color: '#52647d' }}>{p.shortRole}</small>
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
