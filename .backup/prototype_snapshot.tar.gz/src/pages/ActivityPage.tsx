import { Link, useSearchParams } from 'react-router-dom'
import { Award, Bookmark, CheckCircle2, History, Lock, Sparkles, Target, Trophy } from 'lucide-react'
import { useArena } from '../app/arenaContext'
import PermissionGate from '../components/PermissionGate'

type ActivityTab =
  | 'contributions'
  | 'missions'
  | 'submissions'
  | 'applications'
  | 'saved'
  | 'xp'
  | 'progress'

const VALID_ACTIVITY_TABS: ActivityTab[] = [
  'contributions',
  'missions',
  'submissions',
  'applications',
  'saved',
  'xp',
  'progress',
]

export default function ActivityPage() {
  const { state, currentMember, xpBalance, levelProgress, toggleBookmark } = useArena()
  const [searchParams, setSearchParams] = useSearchParams()
  const paramTab = searchParams.get('tab') as ActivityTab | null
  const tab: ActivityTab = paramTab && VALID_ACTIVITY_TABS.includes(paramTab) ? paramTab : 'contributions'

  const changeTab = (next: ActivityTab) => {
    setSearchParams({ tab: next })
  }

  return (
    <PermissionGate title="My Activity">
      {currentMember && (() => {
        const myContributions = state.contributionRecords.filter((c) => c.memberId === currentMember.id)
        const myCreatedMissions = state.missions.filter((m) => m.creatorMemberId === currentMember.id)
        const mySubmissions = state.submissions.filter((s) => s.memberId === currentMember.id)
        const myApplications = state.missionParticipations.filter(
          (p) => p.memberId === currentMember.id && (p.status === 'applied' || p.status === 'accepted' || p.status === 'declined'),
        )
        const myBookmarks = state.savedBookmarks.filter((b) => b.memberId === currentMember.id)
        const myXpLedger = state.xpTransactions
          .filter((tx) => tx.memberId === currentMember.id)
          .slice()
          .reverse()
        const myCpEvents = state.cpEvents.filter(
          (e) => e.memberId === currentMember.id && e.seasonId === state.currentSeason.id,
        )
        const myTotalSeasonCp = myCpEvents.reduce((sum, e) => sum + e.cpAmount, 0)
        const myAttendanceCp = myCpEvents
          .filter((e) => e.activityCategory === 'event_attendance')
          .reduce((sum, e) => sum + e.cpAmount, 0)
        const mySupportCp = myCpEvents
          .filter((e) => e.activityCategory === 'community_support')
          .reduce((sum, e) => sum + e.cpAmount, 0)
        const unlockedIds = new Set(
          state.memberAchievements.filter((ma) => ma.memberId === currentMember.id).map((ma) => ma.achievementId),
        )

        return (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div className="page-intro" style={{ marginBottom: 0 }}>
              <div>
                <span className="section-kicker">PERSONAL TRACKER &amp; LEDGER</span>
                <h1>My Activity<span className="intro-period">.</span></h1>
                <p>
                  Every approved deliverable, mission escrow, XP ledger mutation, seasonal CP total, and unlocked achievement for <b>{currentMember.displayName}</b>.
                </p>
              </div>
              <Link className="button button-quiet" to="/leaderboards">
                <Trophy size={15} /> View Leaderboards
              </Link>
            </div>

            <div className="stats-row">
              <div className="stat-card">
                <div className="stat-top">Lifetime XP (Monotonic) <span><Award size={15} /></span></div>
                <strong>{xpBalance.lifetimeXp.toLocaleString()} XP</strong>
                <small><i /> Level {levelProgress.level} / 30</small>
              </div>
              <div className="stat-card">
                <div className="stat-top">Spendable XP <span><Sparkles size={15} /></span></div>
                <strong>{xpBalance.spendableXp.toLocaleString()} XP</strong>
                <small><i /> Available to fund missions</small>
              </div>
              <div className="stat-card">
                <div className="stat-top">Reserved Escrow XP <span><Lock size={15} /></span></div>
                <strong>{xpBalance.reservedXp.toLocaleString()} XP</strong>
                <small><i /> Locked in active missions</small>
              </div>
              <div className="stat-card">
                <div className="stat-top">Season CP <span><Trophy size={15} /></span></div>
                <strong>{myTotalSeasonCp} CP</strong>
                <small><i /> Separate from XP ledger</small>
              </div>
            </div>

            <div className="arena-tabs" role="tablist">
              {(
                [
                  ['contributions', `Contributions (${myContributions.length})`],
                  ['missions', `Created Missions (${myCreatedMissions.length})`],
                  ['submissions', `Submissions (${mySubmissions.length})`],
                  ['applications', `Applications (${myApplications.length})`],
                  ['saved', `Saved (${myBookmarks.length})`],
                  ['xp', `XP History (${myXpLedger.length})`],
                  ['progress', `Progress & Recognition (${unlockedIds.size}/${state.achievements.length})`],
                ] as const
              ).map(([id, label]) => (
                <button
                  key={id}
                  type="button"
                  role="tab"
                  aria-selected={tab === id}
                  className={`arena-tab ${tab === id ? 'active' : ''}`}
                  onClick={() => changeTab(id)}
                >
                  {label}
                </button>
              ))}
            </div>

            {tab === 'contributions' && (
              <div className="dashboard-panel">
                <h2>Verified Contribution Records</h2>
                {myContributions.length === 0 ? (
                  <p style={{ color: '#52647d', margin: 0 }}>Complete a mission, Academy path, or verified event to build your contribution record.</p>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                    {myContributions.map((cr) => (
                      <div key={cr.id} style={{ padding: 12, border: '1px solid #e3ebf5', borderRadius: 8 }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8, flexWrap: 'wrap' }}>
                          <b>{cr.title}</b>
                          <span className="tag">House {cr.houseId} · {cr.sourceKind}</span>
                        </div>
                        <div style={{ fontSize: 13, color: '#52647d', marginTop: 4 }}>{cr.deliverableSummary}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {tab === 'missions' && (
              <div className="arena-grid-2">
                {myCreatedMissions.length === 0 ? (
                  <div className="empty-state">
                    <span><Target size={22} /></span>
                    <h3>No created missions yet</h3>
                    <p>Members with Mission Creator permission can launch funded missions using Spendable XP.</p>
                  </div>
                ) : (
                  myCreatedMissions.map((m) => (
                    <div className="listing-card" key={m.id}>
                      <div className="listing-top">
                        <span className="listing-kind">{m.status}</span>
                        <span className="tag">House {m.houseId}</span>
                      </div>
                      <h3>{m.title}</h3>
                      <p>Escrow remaining: <b>{m.budget.remainingReservedXp} XP</b> · Settled: {m.budget.settledXp} XP · Refunded: {m.budget.refundedXp} XP</p>
                      <div className="listing-bottom">
                        <span className="listing-reward">+{m.budget.rewardPerContributorXp} XP</span>
                        <Link className="arrow-button" to={`/missions/${m.id}`}>Manage</Link>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {tab === 'submissions' && (
              <div className="arena-table-wrap">
                <table className="arena-table">
                  <thead>
                    <tr>
                      <th>Mission</th>
                      <th>Summary</th>
                      <th>Status</th>
                      <th>Version</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mySubmissions.map((s) => {
                      const m = state.missions.find((x) => x.id === s.missionId)
                      return (
                        <tr key={s.id}>
                          <td><b>{m?.title ?? s.missionId}</b></td>
                          <td>{s.summary}</td>
                          <td><span className="listing-kind">{s.status.replace('_', ' ')}</span></td>
                          <td>v{s.version}</td>
                          <td><Link className="button button-quiet button-small" to={`/missions/${s.missionId}`}>Open</Link></td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {tab === 'applications' && (
              <div className="dashboard-panel">
                <h2>Mission Applications</h2>
                {myApplications.length === 0 ? (
                  <p style={{ color: '#52647d', margin: 0 }}>You have not applied to any application-gated missions.</p>
                ) : (
                  myApplications.map((app) => {
                    const m = state.missions.find((x) => x.id === app.missionId)
                    return (
                      <div key={app.id} style={{ padding: 12, borderTop: '1px solid #e6edf6', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <div>
                          <b>{m?.title ?? app.missionId}</b>
                          <div style={{ fontSize: 12.5, color: '#52647d' }}>{app.applicationNote}</div>
                        </div>
                        <span className="listing-kind">{app.status}</span>
                      </div>
                    )
                  })
                )}
              </div>
            )}

            {tab === 'saved' && (
              <div className="arena-grid-3">
                {myBookmarks.length === 0 ? (
                  <div className="empty-state">
                    <span><Bookmark size={22} /></span>
                    <h3>Nothing bookmarked</h3>
                    <p>Save Missions, Opportunities, Projects, or Resources to revisit them here.</p>
                  </div>
                ) : (
                  myBookmarks.map((b) => {
                    const label =
                      b.targetType === 'mission'
                        ? state.missions.find((m) => m.id === b.targetId)?.title
                        : b.targetType === 'opportunity'
                          ? state.opportunities.find((o) => o.id === b.targetId)?.title
                          : b.targetType === 'project'
                            ? state.projects.find((p) => p.id === b.targetId)?.title
                            : state.resources.find((r) => r.id === b.targetId)?.title
                    return (
                      <div className="dashboard-panel" key={`${b.targetType}-${b.targetId}`}>
                        <span className="tag">{b.targetType}</span>
                        <h3 style={{ margin: '8px 0' }}>{label ?? b.targetId}</h3>
                        <div style={{ display: 'flex', gap: 8 }}>
                          {b.targetType === 'mission' && (
                            <Link className="button button-bright button-small" to={`/missions/${b.targetId}`}>Open</Link>
                          )}
                          <button
                            type="button"
                            className="button button-quiet button-small"
                            onClick={() => toggleBookmark(b.targetType, b.targetId)}
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                    )
                  })
                )}
              </div>
            )}

            {tab === 'xp' && (
              <div className="arena-table-wrap">
                <table className="arena-table">
                  <thead>
                    <tr>
                      <th><History size={13} style={{ verticalAlign: 'middle' }} /> Type</th>
                      <th>Source</th>
                      <th>Reason</th>
                      <th>Lifetime Δ</th>
                      <th>Spendable Δ</th>
                      <th>Reserved Δ</th>
                    </tr>
                  </thead>
                  <tbody>
                    {myXpLedger.map((tx) => (
                      <tr key={tx.id}>
                        <td><span className="listing-kind">{tx.transactionType}</span></td>
                        <td>{tx.sourceType}</td>
                        <td>{tx.reason}</td>
                        <td>{tx.deltaLifetime >= 0 ? `+${tx.deltaLifetime}` : tx.deltaLifetime}</td>
                        <td>{tx.deltaSpendable >= 0 ? `+${tx.deltaSpendable}` : tx.deltaSpendable}</td>
                        <td>{tx.deltaReserved >= 0 ? `+${tx.deltaReserved}` : tx.deltaReserved}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {tab === 'progress' && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                <div className="dashboard-panel">
                  <div className="panel-title">
                    <div>
                      <span className="section-kicker">30-LEVEL SYSTEM &amp; SEASONAL CAPS</span>
                      <h2>Level {levelProgress.level} · {currentMember.ascendancyRank}</h2>
                    </div>
                    <span className="listing-kind">
                      {levelProgress.isMaxLevel ? 'Max Level 30' : `${levelProgress.xpRemainingToNext} XP to Level ${levelProgress.level + 1}`}
                    </span>
                  </div>
                  <div className="progress-track" style={{ marginBottom: 12 }}>
                    <i style={{ width: `${levelProgress.progressPercent}%` }} />
                  </div>
                  <div style={{ fontSize: 13, color: '#52647d', display: 'flex', gap: 18, flexWrap: 'wrap' }}>
                    <span>Event Attendance CP Cap: <b>{myAttendanceCp} / {state.config.seasonalCpCaps.eventAttendancePerSeason}</b></span>
                    <span>Community Support CP Cap: <b>{mySupportCp} / {state.config.seasonalCpCaps.communitySupportPerSeason}</b></span>
                    <span>Mentorship Pair Cap: <b>{state.config.seasonalCpCaps.mentorshipPairPerSeason} CP / pair</b></span>
                  </div>
                </div>

                <div className="dashboard-panel">
                  <div className="panel-title">
                    <h2>Achievements ({unlockedIds.size} / {state.achievements.length})</h2>
                    <span style={{ fontSize: 12.5, color: '#52647d' }}>Zero silent XP bonuses — recognition only</span>
                  </div>
                  <div className="achievement-grid">
                    {state.achievements.map((ach) => {
                      const earned = unlockedIds.has(ach.id)
                      return (
                        <article className={`achievement-card ${earned ? 'achievement-earned' : 'achievement-locked'}`} key={ach.id}>
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <span className="tag">{ach.code}</span>
                            {earned && <CheckCircle2 size={16} color="#1e5cb5" />}
                          </div>
                          <h3>{ach.title}</h3>
                          <p>{ach.description}</p>
                          <small>{earned ? 'Unlocked' : `Condition: ${ach.unlockConditionLabel}`}</small>
                        </article>
                      )
                    })}
                  </div>
                </div>
              </div>
            )}
          </div>
        )
      })()}
    </PermissionGate>
  )
}
