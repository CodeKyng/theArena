import { useState, type FormEvent } from 'react'
import { Building2, CheckCircle2, Info, Plus } from 'lucide-react'
import { useArena } from '../app/arenaContext'
import PermissionGate from '../components/PermissionGate'
import type { OrganisationProfile } from '../domain/types'

export default function OrganisationsPage() {
  const {
    state,
    currentMember,
    activeOrganisation,
    memberOrganisations,
    createOrg,
    switchOrg,
  } = useArena()

  const [name, setName] = useState('')
  const [kind, setKind] = useState<OrganisationProfile['kind']>('Project')
  const [ecosystem, setEcosystem] = useState('')
  const [tagline, setTagline] = useState('')
  const [description, setDescription] = useState('')
  const [website, setWebsite] = useState('')

  const handleCreate = (e: FormEvent) => {
    e.preventDefault()
    const res = createOrg({ name, kind, ecosystem, tagline, description, website })
    if (res.ok) {
      setName('')
      setEcosystem('')
      setTagline('')
      setDescription('')
      setWebsite('')
    }
  }

  return (
    <PermissionGate title="Organisations">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        <div className="page-intro" style={{ marginBottom: 0 }}>
          <div>
            <span className="section-kicker">UNIFIED ACCOUNT EXTENSION</span>
            <h1>Organisations<span className="intro-period">.</span></h1>
            <p>
              Any verified Spartan can create and represent an Organisation (Project, Brand, Company, Team, or Community Initiative) under the same account—no separate login needed.
            </p>
          </div>
        </div>

        <div className="arena-notice arena-notice-info">
          <Info size={16} />
          <span>
            <b>Strict Separation Guarantee:</b> New organisations start as <b>unverified</b> and never inherit personal XP, numeric Levels, or Ascendancy ranks from their creator.
          </span>
        </div>

        <div className="dashboard-columns">
          <section className="dashboard-panel">
            <h2>Your Organisations &amp; Context Switcher</h2>
            {memberOrganisations.length === 0 ? (
              <p style={{ color: '#52647d' }}>You have not created or joined an organisation yet.</p>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {memberOrganisations.map((org) => {
                  const isActive = activeOrganisation?.id === org.id
                  return (
                    <div key={org.id} style={{ padding: 13, border: '1px solid #d7e2f1', borderRadius: 9, background: isActive ? '#eef5ff' : '#fff' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                          <Building2 size={16} color="#1e5cb5" />
                          <b>{org.name}</b>
                          <span className="tag">{org.kind}</span>
                        </div>
                        <span className={`listing-kind ${org.verificationStatus === 'verified' ? 'kind-success' : 'kind-amber'}`}>
                          {org.verificationStatus.replace('_', ' ')}
                        </span>
                      </div>
                      <p style={{ margin: '6px 0', fontSize: 13, color: '#52647d' }}>{org.tagline} — {org.description}</p>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: 12, color: '#52647d' }}>
                        <span>{org.ecosystem} · Personal XP/Rank Inherited: <b>None (0)</b></span>
                        <button
                          type="button"
                          className={`button button-small ${isActive ? 'button-quiet' : 'button-bright'}`}
                          onClick={() => switchOrg(isActive ? null : org.id)}
                        >
                          {isActive ? <><CheckCircle2 size={13} /> Active Context (Switch to Personal)</> : 'Switch Context'}
                        </button>
                      </div>
                    </div>
                  )
                })}
              </div>
            )}

            <h3 style={{ marginTop: 20 }}>All Arena Directory Organisations ({state.organisations.length})</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {state.organisations.map((org) => {
                const owner = state.members.find((m) => m.id === org.ownerMemberId)
                return (
                  <div key={org.id} style={{ padding: 10, border: '1px solid #e5ecf6', borderRadius: 8, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div>
                      <b>{org.name}</b> <span className="tag">{org.kind}</span>
                      <div style={{ fontSize: 12, color: '#52647d' }}>Owner: {owner?.displayName ?? 'Spartan'} · {org.ecosystem}</div>
                    </div>
                    <span className="listing-kind">{org.verificationStatus.replace('_', ' ')}</span>
                  </div>
                )
              })}
            </div>
          </section>

          <form className="form-panel" onSubmit={handleCreate}>
            <h2 style={{ marginTop: 0 }}><Plus size={17} style={{ verticalAlign: 'middle' }} /> Create Organisation Profile</h2>
            <p style={{ fontSize: 13, color: '#52647d', marginTop: 0 }}>
              Linked to <b>{currentMember?.displayName}</b>. Starts <code>unverified</code> until approved in Control Room.
            </p>
            <div className="form-grid">
              <label className="full-field">
                Organisation Name
                <input required placeholder="e.g. Aegis Research Collective" value={name} onChange={(e) => setName(e.target.value)} />
              </label>
              <label>
                Organisation Type
                <select value={kind} onChange={(e) => setKind(e.target.value as OrganisationProfile['kind'])}>
                  <option value="Project">Project</option>
                  <option value="Brand">Brand</option>
                  <option value="Company">Company</option>
                  <option value="Team">Team</option>
                  <option value="Community Initiative">Community Initiative</option>
                </select>
              </label>
              <label>
                Ecosystem Focus
                <input placeholder="e.g. ZK / Developer Tooling" value={ecosystem} onChange={(e) => setEcosystem(e.target.value)} />
              </label>
              <label className="full-field">
                One-line Tagline
                <input placeholder="What your organisation builds or supports" value={tagline} onChange={(e) => setTagline(e.target.value)} />
              </label>
              <label className="full-field">
                Description
                <textarea rows={3} placeholder="Mission collaboration focus..." value={description} onChange={(e) => setDescription(e.target.value)} />
              </label>
              <label className="full-field">
                Website URL
                <input placeholder="https://..." value={website} onChange={(e) => setWebsite(e.target.value)} />
              </label>
            </div>
            <div style={{ marginTop: 14 }}>
              <button type="submit" className="button button-bright">Create Unverified Organisation</button>
            </div>
          </form>
        </div>
      </div>
    </PermissionGate>
  )
}
