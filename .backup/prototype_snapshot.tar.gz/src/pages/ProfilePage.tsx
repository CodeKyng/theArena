import { useState, type FormEvent } from 'react'
import { Link } from 'react-router-dom'
import { Award, Building2, CheckCircle2, Flame, ShieldCheck, Sliders } from 'lucide-react'
import { useArena } from '../app/arenaContext'
import PermissionGate from '../components/PermissionGate'
import type { HouseId } from '../domain/types'

type ProfileTab = 'identity' | 'membership' | 'portfolio' | 'recognition' | 'settings'

export default function ProfilePage() {
  const {
    state,
    currentMember,
    xpBalance,
    levelProgress,
    memberOrganisations,
    updateProfile,
    updateHouses,
    updatePrivacy,
  } = useArena()

  const [tab, setTab] = useState<ProfileTab>('identity')
  const [displayName, setDisplayName] = useState(currentMember?.displayName ?? '')
  const [headline, setHeadline] = useState(currentMember?.headline ?? '')
  const [bio, setBio] = useState(currentMember?.bio ?? '')
  const [skillsText, setSkillsText] = useState(currentMember?.skills.join(', ') ?? '')
  const [linksText, setLinksText] = useState(currentMember?.publicLinks.join('\n') ?? '')
  const [primaryHouse, setPrimaryHouse] = useState<string>(currentMember?.primaryHouseId ?? '')
  const [secondaryHouse, setSecondaryHouse] = useState<string>(currentMember?.secondaryHouseId ?? '')

  const [connectedX, setConnectedX] = useState(currentMember?.privacy.connectedX ?? '')
  const [connectedGithub, setConnectedGithub] = useState(currentMember?.privacy.connectedGithub ?? '')
  const [connectedWallet, setConnectedWallet] = useState(currentMember?.privacy.connectedWallet ?? '')

  return (
    <PermissionGate title="My Profile">
      {currentMember && (() => {
        const myProjects = state.projects.filter((p) => p.ownerMemberId === currentMember.id)
        const myApprovedSubs = state.submissions.filter(
          (s) => s.memberId === currentMember.id && s.status === 'approved',
        )
        const myAchievements = state.memberAchievements.filter((ma) => ma.memberId === currentMember.id)
        const mySeasonCp = state.cpEvents
          .filter((e) => e.memberId === currentMember.id && e.seasonId === state.currentSeason.id)
          .reduce((sum, e) => sum + e.cpAmount, 0)

        const saveIdentity = (e: FormEvent) => {
          e.preventDefault()
          updateProfile({
            displayName: displayName || currentMember.displayName,
            headline,
            bio,
            skills: skillsText.split(',').map((s) => s.trim()).filter(Boolean),
            publicLinks: linksText.split('\n').map((s) => s.trim()).filter(Boolean),
          })
        }

        return (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <section className="profile-hero-card">
              <div className="profile-cover">
                <span className="profile-level">LEVEL {levelProgress.level} · {currentMember.ascendancyRank.toUpperCase()}</span>
              </div>
              <div className="profile-identity">
                <span className="profile-avatar">{currentMember.avatarInitials}</span>
                <div className="profile-identity-meta">
                  <h2>{currentMember.displayName}</h2>
                  <p>@{currentMember.username} · {currentMember.headline}</p>
                </div>
                <button
                  type="button"
                  className="button button-quiet button-small"
                  onClick={() => setTab('settings')}
                >
                  <Sliders size={14} /> Account Settings
                </button>
              </div>
              <div className="profile-stats">
                <div>
                  <b>{xpBalance.lifetimeXp.toLocaleString()} XP</b>
                  <small>Lifetime XP</small>
                </div>
                <div>
                  <b>{mySeasonCp} CP</b>
                  <small>Season CP</small>
                </div>
                <div>
                  <b>{myAchievements.length} / {state.achievements.length}</b>
                  <small>Achievements</small>
                </div>
                <div>
                  <b>{currentMember.primaryHouseId ? `House ${currentMember.primaryHouseId}` : 'Unassigned'}</b>
                  <small>Primary House</small>
                </div>
              </div>
            </section>

            <div className="arena-tabs" role="tablist">
              {(
                [
                  ['identity', 'Public Identity'],
                  ['membership', 'Arena Membership & Houses'],
                  ['portfolio', `Proof-of-Work Portfolio (${myApprovedSubs.length + myProjects.length})`],
                  ['recognition', `Recognition (${myAchievements.length})`],
                  ['settings', 'Private Settings & Privacy'],
                ] as const
              ).map(([id, label]) => (
                <button
                  key={id}
                  type="button"
                  role="tab"
                  aria-selected={tab === id}
                  className={`arena-tab ${tab === id ? 'active' : ''}`}
                  onClick={() => setTab(id)}
                >
                  {label}
                </button>
              ))}
            </div>

            {tab === 'identity' && (
              <form className="form-panel" onSubmit={saveIdentity}>
                <h2 style={{ marginTop: 0 }}>Edit Public Spartan Identity</h2>
                <div className="form-grid">
                  <label>
                    Display Name
                    <input value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
                  </label>
                  <label>
                    Headline
                    <input value={headline} onChange={(e) => setHeadline(e.target.value)} />
                  </label>
                  <label className="full-field">
                    Bio
                    <textarea rows={3} value={bio} onChange={(e) => setBio(e.target.value)} />
                  </label>
                  <label>
                    Skills (comma-separated)
                    <input value={skillsText} onChange={(e) => setSkillsText(e.target.value)} />
                  </label>
                  <label>
                    Public Links (one URL per line)
                    <textarea rows={2} value={linksText} onChange={(e) => setLinksText(e.target.value)} />
                  </label>
                </div>
                <div style={{ marginTop: 14 }}>
                  <button type="submit" className="button button-bright">Save Public Profile</button>
                </div>
              </form>
            )}

            {tab === 'membership' && (
              <div className="dashboard-columns">
                <section className="dashboard-panel">
                  <h2><Flame size={16} style={{ verticalAlign: 'middle' }} /> House Alignment (0 XP)</h2>
                  <p style={{ fontSize: 13, color: '#52647d' }}>
                    Choose your Primary House and optional Secondary House. Changing Houses updates recommendations without awarding XP.
                  </p>
                  <div className="form-grid">
                    <label>
                      Primary House
                      <select value={primaryHouse || currentMember.primaryHouseId || ''} onChange={(e) => setPrimaryHouse(e.target.value)}>
                        <option value="">None</option>
                        {state.houses.map((h) => (
                          <option key={h.id} value={h.id}>{h.glyph} House {h.name}</option>
                        ))}
                      </select>
                    </label>
                    <label>
                      Secondary House
                      <select value={secondaryHouse || currentMember.secondaryHouseId || ''} onChange={(e) => setSecondaryHouse(e.target.value)}>
                        <option value="">None</option>
                        {state.houses.map((h) => (
                          <option key={h.id} value={h.id}>{h.glyph} House {h.name}</option>
                        ))}
                      </select>
                    </label>
                  </div>
                  <div style={{ marginTop: 12 }}>
                    <button
                      type="button"
                      className="button button-bright"
                      onClick={() => {
                        const p = (primaryHouse || currentMember.primaryHouseId || null) as HouseId | null
                        const s = (secondaryHouse || currentMember.secondaryHouseId || null) as HouseId | null
                        updateHouses(p, s === p ? null : s)
                      }}
                    >
                      Save House Alignment
                    </button>
                  </div>
                </section>

                <section className="dashboard-panel">
                  <h2><Building2 size={16} style={{ verticalAlign: 'middle' }} /> Linked Organisations</h2>
                  <p style={{ fontSize: 13, color: '#52647d' }}>
                    Organisations are linked to your personal account and never inherit personal XP or Ascendancy ranks.
                  </p>
                  {memberOrganisations.length === 0 ? (
                    <Link className="button button-quiet button-small" to="/organisations">Create Organisation Profile</Link>
                  ) : (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                      {memberOrganisations.map((org) => (
                        <div key={org.id} style={{ padding: 10, border: '1px solid #d7e2f1', borderRadius: 8, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <div>
                            <b>{org.name}</b>
                            <div style={{ fontSize: 12, color: '#52647d' }}>{org.kind} · {org.ecosystem}</div>
                          </div>
                          <span className="listing-kind">{org.verificationStatus}</span>
                        </div>
                      ))}
                      <Link className="text-link" to="/organisations">Manage Organisations →</Link>
                    </div>
                  )}
                </section>
              </div>
            )}

            {tab === 'portfolio' && (
              <div className="arena-grid-2">
                <section className="dashboard-panel">
                  <h2>Approved Mission Proof of Work</h2>
                  {myApprovedSubs.length === 0 ? (
                    <p style={{ color: '#52647d', margin: 0 }}>No approved mission submissions yet.</p>
                  ) : (
                    myApprovedSubs.map((s) => {
                      const m = state.missions.find((x) => x.id === s.missionId)
                      return (
                        <div key={s.id} style={{ padding: 10, borderTop: '1px solid #e6edf6' }}>
                          <b>{m?.title}</b>
                          <p style={{ margin: '4px 0', fontSize: 13, color: '#52647d' }}>{s.summary}</p>
                        </div>
                      )
                    })
                  )}
                </section>
                <section className="dashboard-panel">
                  <h2>Published Projects</h2>
                  {myProjects.length === 0 ? (
                    <p style={{ color: '#52647d', margin: 0 }}>No projects published yet. Add one via Explore → Projects.</p>
                  ) : (
                    myProjects.map((p) => (
                      <div key={p.id} style={{ padding: 10, borderTop: '1px solid #e6edf6' }}>
                        <b>{p.title}</b> <span className="tag">{p.status}</span>
                        <p style={{ margin: '4px 0', fontSize: 13, color: '#52647d' }}>{p.tagline}</p>
                      </div>
                    ))
                  )}
                </section>
              </div>
            )}

            {tab === 'recognition' && (
              <div className="dashboard-panel">
                <h2><Award size={16} style={{ verticalAlign: 'middle' }} /> Ascendancy &amp; Unlocked Badges</h2>
                <p style={{ fontSize: 13, color: '#52647d' }}>
                  Current Ascendancy Rank: <b>{currentMember.ascendancyRank}</b> (Explicitly appointed—never unlocked automatically by XP).
                </p>
                <div className="achievement-grid">
                  {myAchievements.map((ma) => {
                    const def = state.achievements.find((a) => a.id === ma.achievementId)
                    if (!def) return null
                    return (
                      <div className="achievement-card achievement-earned" key={ma.id}>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <span className="tag">{def.code}</span>
                          <CheckCircle2 size={15} color="#1e5cb5" />
                        </div>
                        <h3>{def.title}</h3>
                        <p>{def.description}</p>
                      </div>
                    )
                  })}
                </div>
              </div>
            )}

            {tab === 'settings' && (
              <div className="dashboard-panel" style={{ maxWidth: 740 }}>
                <div className="arena-notice arena-notice-info" style={{ marginBottom: 14 }}>
                  <ShieldCheck size={16} />
                  <span>
                    <b>Private Settings:</b> Separated cleanly from your public profile. Controls visibility in Explore People and Leaderboards.
                  </span>
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 18 }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: 9, fontSize: 13.5 }}>
                    <input
                      type="checkbox"
                      checked={currentMember.privacy.publicProfileVisible}
                      onChange={(e) => updatePrivacy({ publicProfileVisible: e.target.checked })}
                    />
                    Show my public Spartan profile in Explore → People
                  </label>
                  <label style={{ display: 'flex', alignItems: 'center', gap: 9, fontSize: 13.5 }}>
                    <input
                      type="checkbox"
                      checked={currentMember.privacy.showOnLeaderboard}
                      onChange={(e) => updatePrivacy({ showOnLeaderboard: e.target.checked })}
                    />
                    Appear on public Seasonal &amp; All-Time CP Leaderboards
                  </label>
                  <label style={{ display: 'flex', alignItems: 'center', gap: 9, fontSize: 13.5 }}>
                    <input
                      type="checkbox"
                      checked={currentMember.privacy.missionAlerts}
                      onChange={(e) => updatePrivacy({ missionAlerts: e.target.checked })}
                    />
                    Receive in-app Mission &amp; Review alerts
                  </label>
                </div>

                <div className="form-grid">
                  <label>
                    Connected GitHub Handle (Simulated)
                    <input value={connectedGithub} onChange={(e) => setConnectedGithub(e.target.value)} placeholder="@handle" />
                  </label>
                  <label>
                    Connected X Handle (Simulated)
                    <input value={connectedX} onChange={(e) => setConnectedX(e.target.value)} placeholder="@handle" />
                  </label>
                  <label className="full-field">
                    Read-only Wallet Address Reference (Simulated — no signing infra)
                    <input value={connectedWallet} onChange={(e) => setConnectedWallet(e.target.value)} placeholder="0x..." />
                  </label>
                </div>
                <div style={{ marginTop: 14 }}>
                  <button
                    type="button"
                    className="button button-bright"
                    onClick={() => updatePrivacy({ connectedGithub, connectedX, connectedWallet })}
                  >
                    Save Connected Handles
                  </button>
                </div>
              </div>
            )}
          </div>
        )
      })()}
    </PermissionGate>
  )
}
