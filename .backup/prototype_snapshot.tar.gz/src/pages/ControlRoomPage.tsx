import { useState, type FormEvent } from 'react'
import { CheckCircle2, FileText, ShieldAlert, Sliders, Users } from 'lucide-react'
import { useArena } from '../app/arenaContext'
import PermissionGate from '../components/PermissionGate'
import { ASCENDANCY_LADDER, PERMISSION_LABELS } from '../domain/constants'
import { calculateLevelProgress } from '../domain/progression'
import type { AscendancyRank, HouseId, PermissionScope } from '../domain/types'

type ControlTab = 'overview' | 'members' | 'high-value' | 'ledger' | 'config' | 'audit'

export default function ControlRoomPage() {
  const {
    state,
    getMemberBalance,
    approveHighValue,
    setOrgVerification,
    appointAscendancy,
    togglePermission,
    adminAdjustXp,
    updateConfig,
  } = useArena()

  const [tab, setTab] = useState<ControlTab>('overview')

  // Ledger adjustment form
  const [adjMemberId, setAdjMemberId] = useState(state.members[1]?.id ?? 'mem-jordan')
  const [adjDelta, setAdjDelta] = useState('100')
  const [adjReason, setAdjReason] = useState('')

  // Ascendancy form
  const [rankMemberId, setRankMemberId] = useState(state.members[1]?.id ?? 'mem-jordan')
  const [newRank, setNewRank] = useState<AscendancyRank>('Gladiator')
  const [rankNote, setRankNote] = useState('')

  // Config draft
  const [orientationXp, setOrientationXp] = useState(String(state.config.systemXpValues.orientationOnce))
  const [lessonXp, setLessonXp] = useState(String(state.config.systemXpValues.academyLesson))
  const [eventCap, setEventCap] = useState(String(state.config.seasonalCpCaps.eventAttendancePerSeason))
  const [supportCap, setSupportCap] = useState(String(state.config.seasonalCpCaps.communitySupportPerSeason))
  const [mentorCap, setMentorCap] = useState(String(state.config.seasonalCpCaps.mentorshipPairPerSeason))

  // Scoped permission editor
  const [permMemberId, setPermMemberId] = useState(state.members[1]?.id ?? 'mem-jordan')
  const [permHouseId, setPermHouseId] = useState<string>('')

  const pendingHighValue = state.missions.filter((m) => m.status === 'pending_review')
  const newbiesCount = state.members.filter((m) => m.onboardingStage === 'newbie').length

  const handleAdjustXp = (e: FormEvent) => {
    e.preventDefault()
    const res = adminAdjustXp(adjMemberId, Number(adjDelta) || 0, adjReason)
    if (res.ok) setAdjReason('')
  }

  const handleSaveConfig = (e: FormEvent) => {
    e.preventDefault()
    updateConfig({
      ...state.config,
      systemXpValues: {
        ...state.config.systemXpValues,
        orientationOnce: Math.max(1, Number(orientationXp) || 20),
        academyLesson: Math.max(1, Number(lessonXp) || 5),
      },
      seasonalCpCaps: {
        eventAttendancePerSeason: Math.max(1, Number(eventCap) || 10),
        communitySupportPerSeason: Math.max(1, Number(supportCap) || 50),
        mentorshipPairPerSeason: Math.max(1, Number(mentorCap) || 60),
      },
    })
  }

  return (
    <PermissionGate requiredAny={['platform.admin', 'finance.admin']} title="Control Room Administration">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
        <div className="arena-hero-banner">
          <span className="section-kicker">PLATFORM GOVERNANCE · CONTROL ROOM</span>
          <h2>Arena Control Room</h2>
          <p>
            Explicitly appoint Ascendancy ranks (never auto-promoted by XP), manage scoped RBAC PermissionGrants, approve &gt;1,500 XP missions, verify organisations, audit ledger adjustments, and tune configurable baselines.
          </p>
        </div>

        <div className="arena-tabs" role="tablist">
          {(
            [
              ['overview', 'Funnel & Orgs'],
              ['members', 'Members, Ascendancy & RBAC'],
              ['high-value', `High-Value Missions (${pendingHighValue.length})`],
              ['ledger', 'XP Ledger Adjustments'],
              ['config', 'Configurable Rules'],
              ['audit', `Audit Log (${state.auditLogs.length})`],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              role="tab"
              aria-selected={tab === id}
              className={`arena-tab ${tab === id ? 'active' : ''}`}
              onClick={() => setTab(id)}
            >
              {label}
            </button>
          ))}
        </div>

        {tab === 'overview' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div className="stats-row">
              <div className="stat-card">
                <div className="stat-top">Total Spartans <span><Users size={15} /></span></div>
                <strong>{state.members.length}</strong>
                <small><i /> {newbiesCount} currently in Newbie onboarding</small>
              </div>
              <div className="stat-card">
                <div className="stat-top">Active Missions <span><CheckCircle2 size={15} /></span></div>
                <strong>{state.missions.filter((m) => m.status === 'active').length}</strong>
                <small><i /> {pendingHighValue.length} awaiting &gt;1,500 XP approval</small>
              </div>
              <div className="stat-card">
                <div className="stat-top">Organisations <span><Sliders size={15} /></span></div>
                <strong>{state.organisations.length}</strong>
                <small><i /> {state.organisations.filter((o) => o.verificationStatus !== 'verified').length} unverified / pending</small>
              </div>
              <div className="stat-card">
                <div className="stat-top">Audit Entries <span><FileText size={15} /></span></div>
                <strong>{state.auditLogs.length}</strong>
                <small><i /> Immutable governance trail</small>
              </div>
            </div>

            <div className="dashboard-panel">
              <h2>Organisation Verification Queue</h2>
              <div className="arena-table-wrap">
                <table className="arena-table">
                  <thead>
                    <tr>
                      <th>Organisation</th>
                      <th>Type</th>
                      <th>Status</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {state.organisations.map((org) => (
                      <tr key={org.id}>
                        <td><b>{org.name}</b></td>
                        <td>{org.kind}</td>
                        <td><span className="listing-kind">{org.verificationStatus}</span></td>
                        <td>
                          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                            <button type="button" className="button button-bright button-small" onClick={() => setOrgVerification(org.id, 'verified')}>Verify</button>
                            <button type="button" className="button button-quiet button-small" onClick={() => setOrgVerification(org.id, 'pending_review')}>Pending</button>
                            <button type="button" className="button button-danger button-small" onClick={() => setOrgVerification(org.id, 'unverified')}>Unverify</button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {tab === 'members' && (
          <div className="dashboard-columns">
            <section className="dashboard-panel">
              <h2>Explicit Ascendancy Appointment</h2>
              <p style={{ fontSize: 12.5, color: '#52647d', marginTop: 0 }}>
                XP levels (1–30) never grant leadership ranks automatically. Appoint Vanguard, Gladiator, Strategos, Elder, or Champion explicitly here.
              </p>
              <div className="form-grid" style={{ marginBottom: 12 }}>
                <label>
                  Member
                  <select value={rankMemberId} onChange={(e) => setRankMemberId(e.target.value)}>
                    {state.members.map((m) => (
                      <option key={m.id} value={m.id}>{m.displayName} ({m.ascendancyRank})</option>
                    ))}
                  </select>
                </label>
                <label>
                  New Ascendancy Rank
                  <select value={newRank} onChange={(e) => setNewRank(e.target.value as AscendancyRank)}>
                    {ASCENDANCY_LADDER.map((r) => (
                      <option key={r.rank} value={r.rank}>{r.rank}</option>
                    ))}
                  </select>
                </label>
                <label className="full-field">
                  Appointment Rationale
                  <input placeholder="Recorded in Ascendancy & Audit Log..." value={rankNote} onChange={(e) => setRankNote(e.target.value)} />
                </label>
              </div>
              <button
                type="button"
                className="button button-bright"
                onClick={() => appointAscendancy(rankMemberId, newRank, rankNote)}
              >
                Appoint Rank
              </button>

              <h3 style={{ marginTop: 20 }}>Member Balances &amp; Ranks</h3>
              <div className="arena-table-wrap">
                <table className="arena-table">
                  <thead>
                    <tr>
                      <th>Member</th>
                      <th>Rank</th>
                      <th>Level</th>
                      <th>Spendable</th>
                    </tr>
                  </thead>
                  <tbody>
                    {state.members.map((m) => {
                      const bal = getMemberBalance(m.id)
                      const lvl = calculateLevelProgress(bal.lifetimeXp, state.config.levelThresholds)
                      return (
                        <tr key={m.id}>
                          <td><b>{m.displayName}</b></td>
                          <td>{m.ascendancyRank}</td>
                          <td>L{lvl.level} ({bal.lifetimeXp} XP)</td>
                          <td>{bal.spendableXp} XP</td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            </section>

            <section className="dashboard-panel">
              <h2>Scoped PermissionGrants (RBAC)</h2>
              <div className="form-grid" style={{ marginBottom: 12 }}>
                <label>
                  Select Member
                  <select value={permMemberId} onChange={(e) => setPermMemberId(e.target.value)}>
                    {state.members.map((m) => (
                      <option key={m.id} value={m.id}>{m.displayName} ({m.ascendancyRank})</option>
                    ))}
                  </select>
                </label>
                <label>
                  Optional House Scope
                  <select value={permHouseId} onChange={(e) => setPermHouseId(e.target.value)}>
                    <option value="">Global (all Houses)</option>
                    {state.houses.map((h) => (
                      <option key={h.id} value={h.id}>Scoped: House {h.name}</option>
                    ))}
                  </select>
                </label>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: 7 }}>
                {(Object.keys(PERMISSION_LABELS) as PermissionScope[]).map((scope) => {
                  const targetHouse = (permHouseId || undefined) as HouseId | undefined
                  const active = state.permissionGrants.some(
                    (g) => g.memberId === permMemberId && g.scope === scope && g.houseId === targetHouse,
                  )
                  return (
                    <div key={scope} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '7px 10px', border: '1px solid #e3ebf5', borderRadius: 7 }}>
                      <div>
                        <b style={{ fontSize: 13 }}>{PERMISSION_LABELS[scope]}</b>
                        <div style={{ fontSize: 11, color: '#52647d' }}><code>{scope}</code> {targetHouse ? `· House ${targetHouse}` : '· Global'}</div>
                      </div>
                      <button
                        type="button"
                        className={`button button-small ${active ? 'button-danger' : 'button-quiet'}`}
                        onClick={() => togglePermission(permMemberId, scope, targetHouse)}
                      >
                        {active ? 'Revoke' : 'Grant'}
                      </button>
                    </div>
                  )
                })}
              </div>
            </section>
          </div>
        )}

        {tab === 'high-value' && (
          <div className="dashboard-panel">
            <h2>Missions Requiring Additional Approval (&gt;1,500 XP Band)</h2>
            {pendingHighValue.length === 0 ? (
              <p style={{ color: '#52647d', margin: 0 }}>No pending high-value missions right now.</p>
            ) : (
              pendingHighValue.map((m) => {
                const creator = state.members.find((x) => x.id === m.creatorMemberId)
                return (
                  <div key={m.id} style={{ padding: 13, border: '1px solid #d7e2f1', borderRadius: 9, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
                    <div>
                      <b>{m.title}</b>
                      <div style={{ fontSize: 12.5, color: '#52647d' }}>
                        Creator: {creator?.displayName} · Reward: {m.budget.rewardPerContributorXp} XP/contributor · Reserved Escrow: {m.budget.totalReservedXp} XP
                      </div>
                    </div>
                    <button type="button" className="button button-bright button-small" onClick={() => approveHighValue(m.id)}>
                      Approve &amp; Activate
                    </button>
                  </div>
                )
              })
            )}
          </div>
        )}

        {tab === 'ledger' && (
          <form className="form-panel" onSubmit={handleAdjustXp} style={{ maxWidth: 680 }}>
            <h2 style={{ marginTop: 0 }}>Audit-Logged XP Ledger Adjustment</h2>
            <p style={{ fontSize: 13, color: '#52647d', marginTop: 0 }}>
              Adjustments append immutable ledger transactions and block negative Spendable XP balances.
            </p>
            <div className="form-grid">
              <label>
                Target Member
                <select value={adjMemberId} onChange={(e) => setAdjMemberId(e.target.value)}>
                  {state.members.map((m) => {
                    const b = getMemberBalance(m.id)
                    return (
                      <option key={m.id} value={m.id}>
                        {m.displayName} (Spendable: {b.spendableXp} XP)
                      </option>
                    )
                  })}
                </select>
              </label>
              <label>
                Spendable Delta (+/- XP)
                <input type="number" value={adjDelta} onChange={(e) => setAdjDelta(e.target.value)} />
              </label>
              <label className="full-field">
                Audit Reason (required)
                <input required placeholder="e.g. Manual hackathon correction or grant adjustment" value={adjReason} onChange={(e) => setAdjReason(e.target.value)} />
              </label>
            </div>
            <div style={{ marginTop: 14 }}>
              <button type="submit" className="button button-bright">Apply Ledger Adjustment</button>
            </div>
          </form>
        )}

        {tab === 'config' && (
          <form className="form-panel" onSubmit={handleSaveConfig} style={{ maxWidth: 720 }}>
            <h2 style={{ marginTop: 0 }}>Configurable Thresholds, XP &amp; Seasonal CP Caps</h2>
            <div className="form-grid">
              <label>
                Onboarding Orientation XP (once)
                <input type="number" value={orientationXp} onChange={(e) => setOrientationXp(e.target.value)} />
              </label>
              <label>
                Academy Lesson XP
                <input type="number" value={lessonXp} onChange={(e) => setLessonXp(e.target.value)} />
              </label>
              <label>
                Event Attendance Seasonal CP Cap
                <input type="number" value={eventCap} onChange={(e) => setEventCap(e.target.value)} />
              </label>
              <label>
                Community Support Seasonal CP Cap
                <input type="number" value={supportCap} onChange={(e) => setSupportCap(e.target.value)} />
              </label>
              <label>
                Mentorship Pair Seasonal CP Cap
                <input type="number" value={mentorCap} onChange={(e) => setMentorCap(e.target.value)} />
              </label>
            </div>
            <div style={{ marginTop: 14 }}>
              <button type="submit" className="button button-bright">Save Platform Config</button>
            </div>
          </form>
        )}

        {tab === 'audit' && (
          <div className="arena-table-wrap">
            <table className="arena-table">
              <thead>
                <tr>
                  <th>Action</th>
                  <th>Actor</th>
                  <th>Summary</th>
                  <th>Timestamp</th>
                </tr>
              </thead>
              <tbody>
                {state.auditLogs.map((log) => {
                  const actor = state.members.find((m) => m.id === log.actorMemberId)
                  return (
                    <tr key={log.id}>
                      <td><span className="listing-kind"><ShieldAlert size={11} /> {log.action}</span></td>
                      <td>{actor?.displayName ?? log.actorMemberId}</td>
                      <td>{log.summary}</td>
                      <td style={{ whiteSpace: 'nowrap', fontSize: 12 }}>{new Date(log.createdAt).toLocaleString()}</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </PermissionGate>
  )
}
